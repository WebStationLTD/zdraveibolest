<?php
/**
 * Plugin Name: Zdravei Yoast Editor Fix
 * Description: Ensures Yoast SEO meta descriptions persist when saving from the block editor.
 * Version: 1.1.0
 * Author: Cursor
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('init', 'zdravei_register_yoast_rest_meta_fields');
function zdravei_register_yoast_rest_meta_fields() {
    $post_types = array('post', 'page', 'services', 'members');
    $keys = array('_yoast_wpseo_focuskw', '_yoast_wpseo_title', '_yoast_wpseo_metadesc');

    foreach ($post_types as $post_type) {
        if (!post_type_exists($post_type)) {
            continue;
        }

        foreach ($keys as $key) {
            register_post_meta($post_type, $key, array(
                'type'              => 'string',
                'single'            => true,
                'show_in_rest'      => true,
                'sanitize_callback' => 'sanitize_text_field',
                'auth_callback'     => function () {
                    return current_user_can('edit_posts');
                },
            ));
        }
    }
}

add_action('enqueue_block_editor_assets', 'zdravei_yoast_block_editor_save_fix', 20);
function zdravei_yoast_block_editor_save_fix() {
    $script = <<<'JS'
( function( wp ) {
    if ( ! wp || ! wp.data ) {
        return;
    }

    const { subscribe, select, dispatch } = wp.data;
    let metaBoxesInitAttempted = false;
    let wasSavingPost = false;

    function syncYoastMetaToEditor() {
        const yoastSelect = select( 'yoast-seo/editor' );
        const editorDispatch = dispatch( 'core/editor' );

        if ( ! yoastSelect || ! editorDispatch || ! editorDispatch.editPost ) {
            return;
        }

        const meta = {};
        const description = yoastSelect.getDescription ? yoastSelect.getDescription() : '';
        const title = yoastSelect.getSeoTitle ? yoastSelect.getSeoTitle() : '';
        const focus = yoastSelect.getFocusKeyphrase ? yoastSelect.getFocusKeyphrase() : '';

        if ( typeof description === 'string' ) {
            meta._yoast_wpseo_metadesc = description;
        }
        if ( typeof title === 'string' ) {
            meta._yoast_wpseo_title = title;
        }
        if ( typeof focus === 'string' ) {
            meta._yoast_wpseo_focuskw = focus;
        }

        if ( Object.keys( meta ).length ) {
            editorDispatch.editPost( { meta } );
        }
    }

    subscribe( function() {
        const editorSelect = select( 'core/editor' );
        const editPostSelect = select( 'core/edit-post' );
        const editPostDispatch = dispatch( 'core/edit-post' );

        if ( ! editorSelect ) {
            return;
        }

        if ( ! metaBoxesInitAttempted && editPostSelect && editPostDispatch ) {
            const isEditorReady = editorSelect.__unstableIsEditorReady
                ? editorSelect.__unstableIsEditorReady()
                : true;

            if (
                isEditorReady &&
                editPostSelect.areMetaBoxesInitialized &&
                ! editPostSelect.areMetaBoxesInitialized() &&
                editPostDispatch.initializeMetaBoxes
            ) {
                editPostDispatch.initializeMetaBoxes();
            }

            if ( isEditorReady ) {
                metaBoxesInitAttempted = true;
            }
        }

        const isSaving = editorSelect.isSavingPost ? editorSelect.isSavingPost() : false;
        const isAutosaving = editorSelect.isAutosavingPost ? editorSelect.isAutosavingPost() : false;

        if ( isSaving && ! isAutosaving && ! wasSavingPost ) {
            syncYoastMetaToEditor();
        }

        wasSavingPost = isSaving;
    } );
} )( window.wp );
JS;

    wp_add_inline_script('wp-edit-post', $script);
}
